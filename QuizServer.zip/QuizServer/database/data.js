export default [
    {
        "Question_Id": 1,
        "Question_Text": "What is the capital of France?",
        "Option_A": "London",
        "Option_B": "Paris",
        "Option_C": "Berlin",
        "Option_D": "Madrid",
        "Correct_Option": "Paris"
    },
    {
        "Question_Id": 2,
        "Question_Text": "What is the capital of France?",
        "Option_A": "London",
        "Option_B": "Paris",
        "Option_C": "Berlin",
        "Option_D": "Madrid",
        "Correct_Option": "Paris"
    },
    
];

export const answers = ["Paris","Paris"];