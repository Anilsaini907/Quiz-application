export default [

    {
        id:1,
        question:"what is Node.js?",
        options:["scripting language", 
        "Runtime language", 
        "Runtime Environment", 
        "Framework", 
        ]
    },
    {
        id:1,
        question:"what is Java?",
        options:["scripting language", 
        "Runtime language", 
        "Object Oriented language", 
        "Framework", 
        ]
    }

]







